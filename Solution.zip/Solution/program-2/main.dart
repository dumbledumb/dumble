import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget{
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String? valueM = "DateTime";
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text("Program - 2"),
        ),
        body: Container(
          child: Column(
            children: [
              Text("Date Time Current"),
              Radio(value: "DateTime", groupValue: valueM, onChanged: (value){
                setState(() {
                  this.valueM = value;
                });
              },),
              Text("Current Location"),
              Radio(value: "Location", groupValue: valueM, onChanged: (value){
                setState(() {
                  this.valueM = value;
                });
              },),
              Text("Next Screen"),
              Radio(value: "Next Screen", groupValue: valueM, onChanged: (value){
                setState(() {
                  this.valueM = value;
                });
              },),
              ElevatedButton(onPressed: (){
                setState(() {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(valueM.toString()))
                  );
                });

              }, child: Text("Do As Directed"))
            ],
          ),
        ),
      ),
    );
  }
}
