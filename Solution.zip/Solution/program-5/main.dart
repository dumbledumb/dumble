import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}
class MyApp extends StatefulWidget{
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  double height = 1.0,breathe = 1.0, length = 1.0;
  String output="";
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Program-5"),
        ),
        body: Center(
          child: Column(
            children: [
              Slider(value: height, onChanged: (value){
                setState(() {
                  this.height = value;
                });
              },max: 5.0,min: 1.0,label: "Select Height",),
              Text("Height: "+height.toStringAsFixed(2)),
              Divider(),
              Slider(value: breathe, onChanged: (value){
                setState(() {
                  this.breathe = value;
                });
              },max: 5.0,min: 1.0,label: "Select Breathe",),
              Text("Breathe: "+breathe.toStringAsFixed(2)),
              Divider(),
              Slider(value: length, onChanged: (value){
                setState(() {
                  this.length = value;
                });
              },max: 5.0,min: 1.0,label: "Select Length",),
              Text("Length"+length.toStringAsFixed(2)),
              Padding(
                padding: EdgeInsets.only(top: 20.0),
                child: ElevatedButton(onPressed: (){
                  setState(() {
                    output = "Your Output is: ${(this.breathe * this.height * this.length).toStringAsFixed(2)}";
                  });

                }, child: Text("Calculate")),
              ),

              Text(output)
            ],
          ),
        ),
      ),
    );
  }
}