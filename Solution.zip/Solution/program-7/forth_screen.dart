import 'package:flutter/material.dart';
import 'package:program6/second_screen.dart';

import 'main.dart';
import 'third_screen.dart';

class Forth_Page extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        "first":(context)=>MainApp(),
        "second":(context)=>Second_Page(),
        "third":(context)=>Third_Page(),
      },
      home: Scaffold(
        appBar: AppBar(
          title: Text("Fourth"),
        ),
        body: Center(
          child: Row(
            children: [

              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'first');
              }, child: Text("First Page")),
              SizedBox(width:20,height:20),
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'second');
              }, child: Text("Second Page")),
              SizedBox(width:20,height:20),
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'third');
              }, child: Text("Third Page")),


            ],
          ),
        ),
      ),
    );
  }

}