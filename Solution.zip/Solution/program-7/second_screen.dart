import 'package:flutter/material.dart';
import 'package:program6/third_screen.dart';

import 'forth_screen.dart';
import 'main.dart';

class Second_Page extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        "first":(context)=>MainApp(),
        "third":(context)=>Third_Page(),
        "forth":(context)=>Forth_Page()
      },
      home: Scaffold(
        appBar: AppBar(
        title: Text("Second"),
      ),
        body: Center(
          child: Row(
            children: [
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'first');
              }, child: Text("First Page")),
              SizedBox(width:20,height:20),
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'third');
              }, child: Text("Third Page")),
              SizedBox(width:20,height:20),
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'forth');
              }, child: Text("Forth Page")),
            ],
          ),
        ),
      ),
    );
  }

}