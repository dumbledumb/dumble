import 'package:flutter/material.dart';
import 'package:program6/forth_screen.dart';
import 'package:program6/second_screen.dart';
import 'package:program6/third_screen.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        "second":(context)=>Second_Page(),
        "third":(context)=>Third_Page(),
        "forth":(context)=>Forth_Page()
      },
      home: Scaffold(
        appBar: AppBar(
          title: Text("Program Seven"),
        ),
        body: Center(
          child: Row(
            children: [
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'second');
              }, child: Text("Second Page")),
              SizedBox(width:20,height:20),
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'third');
              }, child: Text("Third Page")),
              SizedBox(width:20,height:20),
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, 'forth');
              }, child: Text("Forth Page")),
            ],
          ),
        ),
      ),
    );
  }
}
