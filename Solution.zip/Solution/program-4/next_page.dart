import 'package:flutter/material.dart';

class NextPage extends StatelessWidget{
  late String a, b;
  NextPage(@required String a, String b);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Program 4"),
        ),
        body: Text(
          "First Name: $a, Date: $b"
        ),
      ),
    );
  }

}