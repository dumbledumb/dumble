import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'next_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  late String value;

  TextEditingController c1 = TextEditingController();
  TextEditingController c2 = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Program 4"),
        ),
        body: Container(
          child: Column(
            children: [
              TextField(
                controller: c1,
                decoration: InputDecoration(labelText: "Enter First name"),
              ),
              TextField(
                controller: c2,
                decoration: InputDecoration(labelText: "Select Date"),
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime.now(),
                      lastDate: DateTime(2023));

                  if (pickedDate != null) {
                    value = pickedDate.toString();
                    String formattedDate =
                        DateFormat('dd-MM-yyyy').format(pickedDate);

                    c2.text = formattedDate.toString();
                  }
                },
              ),
              ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => NextPage(c1.text, c2.text)));
                  },
                  child: Text("Go to Next Page"))
            ],
          ),
        ),
      ),
    );
  }
}
