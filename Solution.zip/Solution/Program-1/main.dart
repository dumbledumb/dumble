import 'package:flutter/material.dart';
import 'package:program1/tab_1.dart';
import 'package:program1/tab_2.dart';

void main(){
  runApp(myApp());
}
class myApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          appBar: AppBar(
            title: Text("Program - 1"),
            bottom: TabBar(
              tabs: [
                Text("Tab - 1"),
                Text("Tab - 2")
              ],
            ),
          ),
          body: Container(
            padding: EdgeInsets.all(10.0),
            child: TabBarView(
              children: [
                    Tab_1(),
                    Tab_2()
              ],
            ),
          ),
        ),
      ),
    );
  }

}