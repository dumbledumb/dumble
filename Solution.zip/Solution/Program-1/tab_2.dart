import 'package:flutter/material.dart';

class Tab_2 extends StatefulWidget{
  @override
  State<Tab_2> createState() => _Tab_2State();
}

class _Tab_2State extends State<Tab_2> {
 var myValue = "Dhoni";
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Text("Which is Better Player"),
          Row(
            children: [
              RadioMenuButton(value: "Dhoni", onChanged: (value){
              setState(() {
                myValue = value!;
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Your Best Player is:$value"))
                );
              });
              },
                child: Text("M.s Dhoni"),
              groupValue: myValue,)
            ],
          ),
          Row(
            children: [
              RadioMenuButton(value: "Kohli", onChanged: (value){
                setState(() {
                  myValue = value!;
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Your Best Player is:$value"))
                  );
                });

              },
                child: Text("Virat Kohli"),
                groupValue: myValue,),

            ],
          ),

        ],
      ),
    );
  }
}























