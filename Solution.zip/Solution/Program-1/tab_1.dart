import 'package:flutter/material.dart';

class Tab_1 extends StatefulWidget{
  @override
  State<Tab_1> createState() => _Tab_1State();
}

class _Tab_1State extends State<Tab_1> {

  var f1 = false, f2 =false, f3 = false, f4 = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Text("Which Are Your Favourite Player"),
          Row(
            children: [
              Text("M.s Dhoni"),
              Checkbox(value: f1, onChanged: (value){
                setState(() {
                  if(f1==true)
                    {
                      f1 = false;
                    }
                  else{
                    f1 = true;
                  }
                });
              })
            ],
          ),
          Row(
            children: [
              Text("Virat Kohli"),
              Checkbox(value: f2, onChanged: (value){
                setState(() {
                  if(f2==true)
                  {
                    f2 = false;
                  }
                  else{
                    f2 = true;
                  }
                });
              })
            ],
          ),
          Row(
            children: [
              Text("Gautam Gambhir"),
              Checkbox(value: f3, onChanged: (value){
                setState(() {
                  if(f3==true)
                  {
                    f3 = false;
                  }
                  else{
                    f3 = true;
                  }
                });
              })
            ],
          ),
          Row(
            children: [
              Text("Rohit Sharma"),
              Checkbox(value: f4, onChanged: (value){
                setState(() {
                  if(f4==true)
                  {
                    f4 = false;
                  }
                  else{
                    f4 = true;
                  }
                });
              })
            ],
          ),
          ElevatedButton(onPressed: (){
            check();
          }, child: Text(
           "Submit Answer"
          ))
        ],
      ),
    );
  }
  void check(){
    var message = "";
    if(f1 == true)
      message = message + " Ms Dhoni,";
    if(f2 == true)
      message = message + " Virat Kohli,";
    if(f3 == true)
      message = message + " Gauti Gambhir,";
    if(f4 == true)
      message = message + " Rohit Sharma,";

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Your Favourite Player(s) Are:$message"))
    );
  }

}























