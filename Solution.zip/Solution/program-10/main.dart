import 'package:flutter/material.dart';
void main()=> runApp(MyApp());
class MyApp extends StatefulWidget{
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  double value = 1.0;
  String output="";
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Program-10"),
        ),
        body: Center(
          child: Column(
            children: [
              Slider(value: value, onChanged: (value){
                setState(() {
                  this.value = value;
                });
              },max: 5.0,min: 1.0,label: "Select Height",),
              Text(value.toStringAsFixed(2)),
              Divider(),


              Text(output)
            ],
          ),
        ),
      ),
    );
  }
}