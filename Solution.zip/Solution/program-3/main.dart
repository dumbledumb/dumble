import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}
class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Program-3"),
        ),
        body: Column(
          children: [
            Text("Images from Drive or Local"),
            Row(
              children: [
                Image.asset("images/charusatLogo.jpg"),
                Image.asset("images/cmpicaLogo.jpg"),
              ],
            ),
            Text("Images from Network"),
            Row(
              children: [
                Image.network("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_TGsIx61KbAwkzMLiI6YdTv3bid6tg5GCrg&usqp=CAU"),
                Image.network("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQjITdQko_KOcoqccWHD07tRMFelMw0pZWRQ&usqp=CAU")
              ],
            )
          ],
        ),
      ),
    );
  }

}